var build = '201407291212';
var version = "0.1.9";
var changelog = " - Application changelogs, rates, downloads ";
